from django.urls import path

from transaction_service.views import GetTransaction

urlpatterns = [
    #path("/admin", )
    #path("/transaction", AddTransaction.as_view()),
    path("gettransaction/", GetTransaction.as_view()),
]