from django.shortcuts import render
import re
# Create your views here.
from rest_framework import generics
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response

from transaction_service.serializers import TransactionSerializer


class GetTransaction(generics.CreateAPIView):
    serializer_class = TransactionSerializer

    def post(self, request, *args, **kwargs):
        try:
            print(f"request.data {request.data} ")
            new_transaction = TransactionSerializer(data=request.data)
            print(new_transaction)
            if new_transaction.is_valid(raise_exception=True):
                new_transaction.save()
                return Response(new_transaction.data, status=200)
            print(new_transaction.errors)
            response_data = {
                'module': "Transaction",
                'code': "Error100",
                'message': "Exception Occurred"
            }
            return Response(response_data, status=400)

        except KeyError as e:
            response_data = {
                'module': "Transaction",
                'code': "Error 100",
                'message': "Key Error" + str(e)
            }
            return Response(response_data, status=400)
        except ValueError as e:
            response_data = {
                'module': "Transaction",
                'code': "Error 101",
                'message': "Value Error" + str(e)
            }
            return Response(response_data, status=400)
        except ValidationError as e:
            response_data = {
                'module': "Transaction",
                'code': "Error 101",
                'message': "Value Error" + str(e)
            }
            return Response(response_data, status=400)
        except Exception as e:
            print(type(e))
            response_data = {
                'module': "Transaction",
                'code': "Error 101",
                'message': "Value Error" + str(e)
            }
            return Response(response_data, status=500)
