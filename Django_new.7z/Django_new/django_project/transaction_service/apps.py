from django.apps import AppConfig


class TransactionServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transaction_service'
