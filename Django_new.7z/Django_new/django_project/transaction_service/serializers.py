from rest_framework import serializers

from transaction_service.models import Transactions


# for converting objects into datatypes understandable by javascript and front-end frameworks

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transactions
        fields = ('id', 'amount', 'date', 'transaction_type', 'user_id')
