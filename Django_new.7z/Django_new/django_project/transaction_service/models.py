from django.db import models


# Create your models here.
# create a class for each new table and within the class, create another class for metadata of the table created
class Transactions(models.Model):
    id = models.CharField(max_length=399, db_column="id", primary_key=True)
    amount = models.IntegerField(db_column="amount", blank=False, null=False)
    date = models.TextField(db_column="Date_of_Transaction", blank=False, null=False)
    transaction_type = models.IntegerField(db_column="transaction_type", blank=False, null=False)
    user_id = models.TextField(db_column="user_id", blank=False, null=False)
    # task_id = models.ForeignKey(db_column="task_id",blank="False",null=False)

    # metadata of the table

    class Meta:
        db_table = "Transactions"
